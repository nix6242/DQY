# Bộ thực hành Postman: bắt đầu trên máy của bạn

Bộ này là bài học kèm cẩm nang Postman tiếng Việt. Bạn tự chạy một API trên **máy tính của bạn**, sau đó dùng Postman gửi request tới API đó. Sau khi tải Node.js và Postman, các request trong bài học không cần Internet. Đây là API giả để học, không phải mẫu triển khai hệ thống thực tế.

## 1. Bạn có những tệp gì và mỗi tệp dùng để làm gì?

| Tệp | Công dụng |
|---|---|
| `demo-server.mjs` | API mẫu dùng Node.js; không cần `npm install` hoặc thư viện ngoài. |
| `Postman-Local.postman_collection.json` | Collection schema 2.1: 21 request đã có mô tả và assertion. |
| `Postman-Local.postman_environment.json` | Environment có địa chỉ server và biến cho token/id. Token/id ban đầu trống. |
| `data.csv` | 4 dòng dữ liệu để Runner thử tạo sản phẩm: 1 hợp lệ, 3 lỗi có chủ đích. |
| `sample-upload.txt` | Tệp mẫu cho bài upload; không phải tài liệu riêng tư. |
| `README-thuc-hanh.md` | Hướng dẫn bạn đang đọc. |

Giải nén `Bo-thuc-hanh-Postman.zip` vào một thư mục dễ tìm. Trong hướng dẫn, thư mục này có tên `Bo-thuc-hanh-Postman`; nếu máy bạn tạo tên khác thì thay đường dẫn tương ứng.

## 2. Cài và kiểm tra Node.js, Postman

1. Tải **Node.js bản LTS được hỗ trợ, phiên bản 20 trở lên** tại https://nodejs.org/en/download; bản LTS mới được hỗ trợ là lựa chọn phù hợp. Không chọn bản quá cũ chỉ vì bài tập có thể chạy được.
2. Tải **Postman Desktop** tại https://www.postman.com/downloads/. App trên máy là cách dễ nhất để gọi `127.0.0.1`.
3. Sau khi cài Node.js, đóng rồi mở lại Terminal/PowerShell. Gõ:

```text
node --version
```

Bạn phải thấy dạng `v20...`, `v22...`, `v24...` hoặc bản mới tương thích. Nếu thấy `node is not recognized` / `command not found`, Node chưa được cài đúng hoặc cửa sổ terminal chưa nhận PATH mới.

`127.0.0.1` nghĩa là **chính máy đang gửi request**. Nếu bạn chạy server trên máy đám mây rồi dùng Postman trên laptop, hai địa chỉ này không tự nối nhau. Bài này yêu cầu chạy server và Postman trên cùng máy. Nếu dùng Postman Web, bạn cần Desktop Agent hoạt động trên máy đó và chọn đúng agent; Cloud Agent không gọi được API loopback của máy bạn.

## 3. Mở đúng thư mục và chạy API

### Windows: PowerShell

Mở thư mục vừa giải nén bằng File Explorer. Bấm thanh địa chỉ, gõ `powershell`, nhấn Enter để mở PowerShell ngay trong thư mục. Hoặc, nếu thư mục nằm trong Downloads:

```powershell
cd "$env:USERPROFILE\Downloads\Bo-thuc-hanh-Postman"
node --version
node .\demo-server.mjs
```

### macOS: Terminal

```bash
cd "$HOME/Downloads/Bo-thuc-hanh-Postman"
node --version
node ./demo-server.mjs
```

### Linux: Terminal

```bash
cd "$HOME/Downloads/Bo-thuc-hanh-Postman"
node --version
node ./demo-server.mjs
```

Nếu Downloads của bạn có tên/đường dẫn khác, đổi phần đường dẫn. Bạn cũng có thể mở terminal trong thư mục hoặc kéo thư mục vào terminal để lấy đường dẫn, thay vì đoán.

Thành công sẽ có thông báo:

```text
API bài học: http://127.0.0.1:4010
Chỉ phục vụ trên máy này. Ctrl+C để dừng; dữ liệu được đặt lại khi khởi động lại.
```

Giữ cửa sổ này mở. Không gõ lệnh Newman vào cửa sổ đang chạy server; mở cửa sổ terminal thứ hai khi cần. Mở trình duyệt tới http://127.0.0.1:4010/health sẽ thấy:

```json
{"status":"ok","service":"postman-practice"}
```

API chỉ lắng nghe loopback, không mở ra mạng LAN. Dữ liệu lưu trong RAM, khởi động lại thì về 3 sản phẩm ban đầu; token cũ cũng mất hiệu lực.

## 4. Import vào Postman và chọn environment

1. Trong Postman, chọn **Import**.
2. Chọn hai tệp `Postman-Local.postman_collection.json` và `Postman-Local.postman_environment.json`. Đợi Import hoàn tất.
3. Trong danh sách Collection, bạn sẽ thấy **Postman Local — Bài thực hành**.
4. Ở nơi chọn environment, chọn **Postman Local**. Nếu để No environment, biến `{{base_url}}` không có giá trị.
5. Mở environment kiểm tra:

| Biến | Giá trị lúc đầu | Ý nghĩa |
|---|---|---|
| `base_url` | `http://127.0.0.1:4010` | Địa chỉ API trên máy bạn. |
| `access_token` | Trống | Request 02 sẽ lưu token giả có hạn 1 giờ. |
| `product_id` | Trống | Request 09 sẽ lưu id sản phẩm vừa tạo. |
| `search_term` | `Laptop` | Từ khóa dùng ở request 04. |

Biến `access_token` được đánh dấu kiểu secret để che hiển thị; việc che hiển thị không thay thế kiểm soát chia sẻ/lưu trữ. Các tệp mẫu xuất sẵn không chứa token thật.

## 5. Thực hành từ request 01 đến 20

Mở folder **01 - Quy trình chính**. Chạy theo thứ tự; mỗi request đều có mô tả. Không nhấn cùng lúc các request phụ thuộc nhau.

| Request | Bạn học gì? | HTTP đúng |
|---|---|---|
| 01 | Kiểm tra server; xóa token/id cũ của lần chạy trước. | 200 |
| 02 | Login bằng tài khoản giả; script lưu token vào environment. | 200 |
| 03 | Đọc danh sách sản phẩm. | 200 |
| 04 | Params: tìm kiếm và phân trang. | 200 |
| 05 | Đọc sản phẩm số 1. | 200 |
| 06 | Body raw JSON + header tự đặt + query. | 200 |
| 07 | Body x-www-form-urlencoded: các giá trị là chuỗi. | 200 |
| 08 | Body form-data: tải một tệp vào API cục bộ. | 200 |
| 09 | Bearer auth + tạo sản phẩm; script lưu `product_id`. | 201 |
| 10 | Dùng biến id để đọc sản phẩm vừa tạo. | 200 |
| 11 | PATCH sửa price/stock, giữ nguyên name. | 200 |
| 12 | Bearer auth để đọc hồ sơ riêng. | 200 |
| 13 | Thiếu token bị từ chối. | 401 |
| 14 | Mật khẩu sai bị từ chối. | 401 |
| 15 | Giá âm bị từ chối. | 400 |
| 16 | JSON thiếu dấu ngoặc bị từ chối. | 400 |
| 17 | Sai Content-Type bị từ chối. | 415 |
| 18 | PUT chưa được hỗ trợ bị từ chối; xem header Allow. | 405 |
| 19 | Xóa sản phẩm bài học; response trống. | 204 |
| 20 | Đọc lại sản phẩm đã xóa để xác nhận không còn. | 404 |

**Ở request 08, phải chọn lại tệp:** mở Body → form-data → hàng `file`, đảm bảo kiểu **File**, chọn `sample-upload.txt` từ thư mục trên máy bạn. Hàng `note` kiểu **Text**. Không tự điền Content-Type cho form-data; Postman cần tạo boundary. Import collection không tự cấp quyền đọc một tệp bất kỳ trên máy bạn.

Sau mỗi lần Send, xem response và **Test Results**. Tên các mục Scripts/Post-response có thể thay đổi theo phiên bản. Các HTTP 400/401/404/405/415 trong request 13–18 và 20 là lỗi **có chủ đích**; test xanh mới là kết quả đúng của bài này.

Request 19 trả 204 nên không có JSON để mở; script kiểm tra response text rỗng. Request 02 và 09 xóa giá trị cũ trước khi gửi để tránh một lỗi mới bị che bởi token/id đã có sẵn.

Nếu sửa/xóa sản phẩm mặc định `id=1` thì request 05 có thể thất bại. Dừng và chạy lại server để đặt lại bài học. Chạy lại request 01 → 02 → 09 theo thứ tự trước khi dùng request phụ thuộc; chỉ chạy request 02 sẽ không tạo sản phẩm.

## 6. Chạy folder bằng Collection Runner

Sau khi đã thử từng request và chọn file ở request 08:

1. Chọn folder **01 - Quy trình chính** → Run/Runner.
2. Chọn environment **Postman Local**.
3. Bắt đầu với **Iterations = 1**, chưa chọn data.csv.
4. Run và xem từng assertion. Mong đợi 20 request hoàn tất, không assertion thất bại.
5. Nếu phiên bản Runner có tùy chọn giữ giá trị biến sau run, bật tùy chọn đó khi muốn dùng lại token. Cách dễ kiểm tra là mở environment sau run; nếu `access_token` vẫn trống, Send riêng request 02.

Runner của folder 01 tạo rồi xóa một sản phẩm. Không chạy folder này nhiều vòng vô ý khi học. Server là sandbox học tập nên bạn có thể khởi động lại để đặt lại trạng thái.

### Chạy data.csv riêng

1. Send riêng request **02** để chắc chắn có token trong environment đang chọn.
2. Chọn folder **02 - Bài tập dữ liệu** → Run.
3. Chọn environment **Postman Local** và chọn file **data.csv** làm data file.
4. Kiểm tra preview có đúng 4 dòng và các cột `name`, `price`, `stock`, `expected_status`.
5. Chạy đủ 4 dòng. Một dòng hợp lệ phải trả 201, ba dòng lỗi phải trả 400 với mã `INVALID_PRODUCT`.

Script đọc dữ liệu bằng `pm.iterationData`, chuyển price/stock từ CSV thành số, rồi dựng JSON. Không có dữ liệu CSV thì request dùng một sản phẩm mặc định. Sau khi tạo thành công, script dùng `pm.sendRequest` xóa sản phẩm đó và kiểm tra HTTP 204 cùng body trống. Đây là phần dựng sẵn cho bài học; người mới có thể dùng trước khi học cách viết callback.

Nút Send một request riêng không tự gắn dữ liệu CSV trong Runner. Không cần chỉnh body bằng tay thành từng dòng CSV.

## 7. Các API và quy tắc dữ liệu

| Method + path | Auth | Request/response chính |
|---|---|---|
| GET `/health` | Không | `{status:"ok",service:"postman-practice"}`. |
| POST `/auth/login` | Không | JSON `{email,password}` → `{access_token,token_type:"Bearer",expires_in:3600}`. |
| GET `/products` | Không | `{data:[{id,name,price,stock}],page,limit,total}`. Query tùy chọn, ví dụ `?q=Laptop&page=1&limit=10`. Khi bỏ tham số, page mặc định 1, limit mặc định 10; limit tối đa 100. Không gửi page/limit rỗng. |
| GET `/products/:id` | Không | Một sản phẩm hoặc 404. |
| POST `/products` | Bearer | JSON đủ name, price, stock → 201 + sản phẩm + header Location. |
| PATCH `/products/:id` | Bearer | JSON có ít nhất một trường name/price/stock → sản phẩm đã sửa. |
| DELETE `/products/:id` | Bearer | 204, body trống; không tìm thấy → 404. |
| GET `/private/profile` | Bearer | `{email:"learner@example.test",role:"learner"}`. |
| POST `/echo` | Không | JSON hoặc form URL encoded → `{method,query,headers,body}`. |
| POST `/upload` | Không | form-data có một trường file kiểu File → `{fields,files:[{field,filename,content_type,size,sha256}]}`. |

**Thông tin login giả:** `learner@example.test` / `postman-demo-2026`. Đây là dữ liệu công khai cho bài thực hành, không dùng cho một tài khoản thật. Token được tạo mới lúc login và hết hạn sau 1 giờ; khởi động lại server sẽ xóa tất cả token. API bài học không có refresh token.

- `name`: chuỗi không rỗng sau khi bỏ khoảng trắng đầu/cuối, tối đa 120 ký tự.
- `price`: số hữu hạn, không âm; ví dụ `3500000`, không phải chuỗi `"3500000"`.
- `stock`: số nguyên an toàn, không âm; `1.5` bị từ chối.
- POST cần đủ 3 trường; PATCH chỉ gửi trường cần sửa. Trường ngoài name/price/stock bị từ chối.
- JSON lỗi → 400; thiếu/sai/hết hạn token → 401; endpoint/sản phẩm không có → 404; sai method → 405; sai Content-Type → 415; body quá 64 KiB → 413.
- Lỗi có dạng `{ "error": { "code": "...", "message": "..." } }`.
- Echo che Authorization/Cookie/Proxy-Authorization/X-Api-Key bằng `[REDACTED]`. Không đưa dữ liệu riêng tư thật vào request bài học; các header/tên khác vẫn có thể được trả về.
- Upload nhận tối đa một tệp, chỉ phân tích trong RAM, trả metadata và hash SHA-256, không ghi file vào đĩa. Tổng body request gồm cả form metadata không vượt 64 KiB.
- OPTIONS phục vụ CORS trả 204; điều này không thay thế kiểm tra Bearer trên request cần xác thực.

## 8. Chạy Newman trên dòng lệnh (không bắt buộc cho người mới)

Node chạy API không cần thư viện ngoài. **Newman** là công cụ riêng để chạy collection qua dòng lệnh; lần đầu dùng lệnh npx dưới đây cần Internet để tải package từ npm. Bộ này dùng collection **schema 2.1** tương thích Newman **6.2.3**. Khi một phiên bản Postman mới chuyển đổi/export format khác, hãy dùng lại tệp 2.1 gốc trong ZIP cho các lệnh bên dưới.

Mở terminal thứ hai trong thư mục bộ thực hành. Giữ server chạy ở terminal thứ nhất. Nếu PowerShell trên Windows báo không cho chạy `npx.ps1`, thay từ đầu lệnh `npx` bằng `npx.cmd` để gọi chương trình cùng tên, giữ nguyên phần còn lại; không cần hạ ExecutionPolicy chỉ để làm bài.

```text
npx --yes --package=newman@6.2.3 newman run Postman-Local.postman_collection.json -e Postman-Local.postman_environment.json --folder "01 - Quy trình chính" --working-dir . --export-environment Postman-Local.runtime.postman_environment.json
```

`--working-dir .` giúp Newman tìm **sample-upload.txt** trong thư mục hiện tại. Bỏ tùy chọn hoặc chạy từ sai thư mục có thể khiến request upload thiếu tệp. Đây là lỗi đường dẫn/quyền đọc tệp, không phải lỗi API. Các tên có dấu/có khoảng trắng phải giữ trong dấu nháy như trên.

Lệnh trên tạo `Postman-Local.runtime.postman_environment.json` có token giả vừa lấy. Dùng nó cho lần chạy CSV tiếp theo trong vòng 1 giờ, khi server chưa khởi động lại:

```text
npx --yes --package=newman@6.2.3 newman run Postman-Local.postman_collection.json -e Postman-Local.runtime.postman_environment.json --folder "02 - Bài tập dữ liệu" --working-dir . -d data.csv
```

Không chạy CSV với bản environment gốc token trống; bạn sẽ gặp 401. Nếu mất/hết hạn token, chạy lại lệnh folder 01 trước. Lệnh thứ hai chạy 4 request POST và một request dọn dữ liệu phát sinh qua script. Đánh giá số assertion thất bại và HTTP theo từng dòng thay vì chỉ đếm mọi HTTP 400 là lỗi.

Tệp `*.runtime.postman_environment.json` là đầu ra tạm có token. Không commit/share nó; bản mẫu trong ZIP luôn để token/id trống. Không thêm `--insecure` hoặc tắt kiểm tra TLS cho API thật; lab này dùng HTTP trên loopback vì chưa có TLS và không truyền bí mật thật.

## 9. Lỗi thường gặp và cách sửa

| Hiện tượng | Cách kiểm tra và xử lý |
|---|---|
| `Could not send request` / `ECONNREFUSED` | Cửa sổ server có còn chạy không? Thử `/health` trên trình duyệt cùng máy. Dùng đúng `http://127.0.0.1:4010`. Đây chưa phải HTTP 400/500 từ API. |
| `{{base_url}}` còn nguyên / biến đỏ | Chọn environment Postman Local; kiểm tra key viết đúng và biến cùng tên ở scope khác có ghi đè không. |
| 401 ở request đáng lẽ 200/201 | Send request 02; xem `access_token` có giá trị tại environment đang chọn; Bearer dùng đúng biến. Server restart/hết hạn token cần login lại. |
| 404 ở request 10/11/19 | Request 09 đã thành công chưa? Xem product_id; đã xóa hoặc server khởi động lại thì chạy lại workflow. |
| 400 khi tạo sản phẩm | name không trống; price là số không âm; stock là số nguyên không âm; không gửi id hoặc trường ngoài hợp đồng. |
| 415 | Chọn đúng Body raw JSON; hoặc đúng URL encoded/form-data. Với multipart không tự đặt Content-Type/boundary. |
| Upload không có tệp | Chọn lại file ở request 08; check kiểu File; Newman dùng đúng working-dir và đường dẫn có tệp. |
| Cổng 4010 đang được dùng | Dừng server cũ bằng Ctrl+C trong cửa sổ đã mở nó. Không tắt tiến trình lạ nếu chưa biết nó là gì. Có thể đổi cổng như bên dưới. |
| Runner đúng nhưng data.csv báo 401 | Send riêng request 02 để lưu token hiện hành, hoặc dùng environment runtime xuất bởi Newman, không dùng bản gốc trống. |
| Request 13–18/20 trả mã 4xx nhưng test xanh | Đúng bài học: ca lỗi có chủ đích kiểm tra API biết từ chối dữ liệu không hợp lệ. |
| CSV chỉ chạy một dòng | Kiểm tra preview và số iterations; chạy đúng folder 02 với data.csv đủ 4 dòng. |

Nếu cần đổi cổng, trước tiên dừng server của bạn bằng Ctrl+C, rồi chạy:

**PowerShell**

```powershell
$env:POSTMAN_LAB_PORT = "4011"
node .\demo-server.mjs
```

**macOS/Linux**

```bash
POSTMAN_LAB_PORT=4011 node ./demo-server.mjs
```

Đổi `base_url` trong environment thành `http://127.0.0.1:4011`. API không cho bind tới `0.0.0.0` hoặc địa chỉ public/LAN. Khi dùng IPv6 loopback có thể đặt POSTMAN_LAB_HOST là `::1`; URL cần dấu ngoặc vuông `http://[::1]:4010`. Người mới nên giữ mặc định IPv4.

## 10. Hoàn thành bài học và luyện lại

Bạn đã đạt bài học nếu tự giải thích và thực hiện được: API là gì; URL/method/query/header/body khác nhau thế nào; JSON và form khác nhau; biến môi trường giúp tránh sửa URL/token từng request; Bearer giữ endpoint riêng; vì sao POST 201, DELETE 204, dữ liệu sai 400 và thiếu token 401; vì sao 404 có thể là kết quả mong đợi; cách xem Test Results và chạy CSV.

Dừng server bằng Ctrl+C. Khởi động lại rồi chạy lại folder 01 để luyện từ dữ liệu sạch. Không deploy server này thành website/API doanh nghiệp thật; một hệ thống thực tế cần thiết kế xác thực, lưu dữ liệu, giới hạn request, xử lý file và vận hành phù hợp riêng.
