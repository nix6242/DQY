/** API học Postman chạy cục bộ; không dùng để triển khai thực tế. Node.js >= 20. */
import http from 'node:http';
import { randomBytes, createHash } from 'node:crypto';

const host = process.env.POSTMAN_LAB_HOST || '127.0.0.1';
const port = Number(process.env.POSTMAN_LAB_PORT || 4010);
if (!['127.0.0.1', '::1'].includes(host)) throw new Error('Chỉ được lắng nghe địa chỉ loopback 127.0.0.1 hoặc ::1.');
if (!Number.isInteger(port) || port < 1024 || port > 65535) throw new Error('POSTMAN_LAB_PORT phải là số nguyên từ 1024 đến 65535.');
const MAX_BODY = 64 * 1024;
const EMAIL = 'learner@example.test';
const PASSWORD = 'postman-demo-2026'; // Thông tin giả chỉ cho bài học, không phải bí mật thực tế.
let nextId = 4;
const products = new Map([
  [1, { id: 1, name: 'Laptop doanh nghiệp', price: 18000000, stock: 12 }],
  [2, { id: 2, name: 'Bàn phím cơ', price: 1500000, stock: 25 }],
  [3, { id: 3, name: 'Chuột không dây', price: 650000, stock: 30 }],
]);
const sessions = new Map();
class ApiError extends Error {
  constructor(status, code, message) { super(message); this.status = status; this.code = code; }
}
function fail(status, code, message) { throw new ApiError(status, code, message); }
function json(res, status, value, headers = {}) {
  res.writeHead(status, { 'Content-Type': 'application/json; charset=utf-8', ...headers });
  res.end(JSON.stringify(value));
}
function empty(res, status, headers = {}) { res.writeHead(status, headers); res.end(); }
function allow(req, res, methods) {
  if (!methods.includes(req.method)) {
    res.setHeader('Allow', [...methods, 'OPTIONS'].join(', '));
    fail(405, 'METHOD_NOT_ALLOWED', 'Phương thức HTTP không được hỗ trợ tại đường dẫn này.');
  }
}
function readBody(req) {
  return new Promise((resolve, reject) => {
    let count = 0, exceeded = false;
    const chunks = [];
    req.on('data', chunk => {
      count += chunk.length;
      if (count > MAX_BODY) { exceeded = true; chunks.length = 0; }
      else if (!exceeded) chunks.push(chunk);
    });
    req.on('end', () => exceeded
      ? reject(new ApiError(413, 'BODY_TOO_LARGE', 'Body tối đa 64 KiB.'))
      : resolve(Buffer.concat(chunks)));
    req.on('error', reject);
  });
}
function mediaType(req) { return String(req.headers['content-type'] || '').split(';')[0].trim().toLowerCase(); }
async function readJson(req) {
  if (mediaType(req) !== 'application/json') fail(415, 'UNSUPPORTED_MEDIA_TYPE', 'Hãy chọn Body → raw → JSON (Content-Type: application/json).');
  const data = await readBody(req);
  try { return JSON.parse(data.toString('utf8')); }
  catch { fail(400, 'INVALID_JSON', 'Body không phải JSON hợp lệ. Kiểm tra dấu ngoặc, dấu phẩy và dấu nháy kép.'); }
}
function object(value) { return value !== null && typeof value === 'object' && !Array.isArray(value); }
function authorize(req) {
  const match = /^Bearer ([A-Za-z0-9_-]+)$/.exec(String(req.headers.authorization || ''));
  const session = match && sessions.get(match[1]);
  if (!session || session.expiresAt <= Date.now()) {
    if (match) sessions.delete(match[1]);
    fail(401, 'UNAUTHORIZED', 'Thiếu token, token không hợp lệ hoặc đã hết hạn. Hãy đăng nhập lại.');
  }
  return session;
}
function validateProduct(body, partial = false) {
  if (!object(body)) fail(400, 'INVALID_PRODUCT', 'Body sản phẩm phải là một JSON object.');
  const keys = Object.keys(body);
  if (keys.length === 0 || keys.some(k => !['name', 'price', 'stock'].includes(k))) fail(400, 'INVALID_PRODUCT', 'Chỉ nhận name, price và stock; cần ít nhất một trường.');
  if (!partial && !['name', 'price', 'stock'].every(k => Object.hasOwn(body, k))) fail(400, 'INVALID_PRODUCT', 'Khi tạo sản phẩm cần đủ name, price và stock.');
  const result = {};
  if (Object.hasOwn(body, 'name')) {
    if (typeof body.name !== 'string' || !body.name.trim() || body.name.trim().length > 120) fail(400, 'INVALID_PRODUCT', 'name phải là chuỗi không rỗng, tối đa 120 ký tự.');
    result.name = body.name.trim();
  }
  if (Object.hasOwn(body, 'price')) {
    if (typeof body.price !== 'number' || !Number.isFinite(body.price) || body.price < 0) fail(400, 'INVALID_PRODUCT', 'price phải là số hữu hạn không âm.');
    result.price = body.price;
  }
  if (Object.hasOwn(body, 'stock')) {
    if (!Number.isSafeInteger(body.stock) || body.stock < 0) fail(400, 'INVALID_PRODUCT', 'stock phải là số nguyên không âm.');
    result.stock = body.stock;
  }
  return result;
}
function positiveInt(value, defaultValue, maximum, name) {
  if (value === null) return defaultValue;
  if (!/^\d+$/.test(value) || Number(value) < 1 || !Number.isSafeInteger(Number(value)) || Number(value) > maximum) fail(400, 'INVALID_QUERY', `${name} phải là số nguyên từ 1 đến ${maximum}.`);
  return Number(value);
}
function safeHeaders(req) {
  const result = { ...req.headers };
  for (const key of ['authorization', 'cookie', 'proxy-authorization', 'x-api-key']) if (Object.hasOwn(result, key)) result[key] = '[REDACTED]';
  return result;
}
function multipart(req, raw) {
  const contentType = String(req.headers['content-type'] || '');
  const match = /(?:^|;)\s*boundary=(?:"([^"\r\n]{1,70})"|([^;\s\r\n]{1,70}))/i.exec(contentType);
  if (!match) fail(400, 'INVALID_MULTIPART', 'Thiếu boundary. Để Postman tự tạo Content-Type khi chọn form-data.');
  const boundary = match[1] || match[2];
  if (!/^[0-9A-Za-z'()+_,./:=? -]{1,70}$/.test(boundary)) fail(400, 'INVALID_MULTIPART', 'Boundary không hợp lệ.');
  // latin1 giữ nguyên từng byte; tệp chỉ đọc trong RAM, không ghi lên đĩa.
  const body = raw.toString('latin1');
  const delimiter = `--${boundary}`;
  if (!body.startsWith(`${delimiter}\r\n`) || !body.endsWith(`${delimiter}--\r\n`) && !body.endsWith(`${delimiter}--`)) fail(400, 'INVALID_MULTIPART', 'Body multipart không hoàn chỉnh.');
  const segments = body.slice(delimiter.length).split(`\r\n${delimiter}`);
  const fields = {}, files = [];
  for (const segment of segments.slice(0, -1)) {
    if (!segment.startsWith('\r\n')) fail(400, 'INVALID_MULTIPART', 'Định dạng multipart không hợp lệ.');
    const part = segment.slice(2);
    const split = part.indexOf('\r\n\r\n');
    if (split < 0) fail(400, 'INVALID_MULTIPART', 'Thiếu header của phần multipart.');
    const header = part.slice(0, split);
    const bytes = Buffer.from(part.slice(split + 4), 'latin1');
    const disposition = /^content-disposition:\s*form-data;[^\r\n]*$/im.exec(header)?.[0];
    const fieldName = disposition && /(?:^|;)\s*name="([^"\r\n]{1,80})"/i.exec(disposition)?.[1];
    if (!fieldName) fail(400, 'INVALID_MULTIPART', 'Thiếu tên trường form-data.');
    const filename = /(?:^|;)\s*filename="([^"\r\n]{0,255})"/i.exec(disposition)?.[1];
    if (filename !== undefined) {
      const cleaned = filename.split(/[\\/]/).at(-1);
      if (fieldName !== 'file' || !cleaned || files.length) fail(400, 'INVALID_MULTIPART', 'Bài học chỉ nhận một tệp trong trường file.');
      const type = /^content-type:\s*([^\r\n]+)$/im.exec(header)?.[1]?.trim() || 'application/octet-stream';
      files.push({ field: fieldName, filename: Buffer.from(cleaned, 'latin1').toString('utf8'), content_type: type, size: bytes.length, sha256: createHash('sha256').update(bytes).digest('hex') });
    } else {
      if (['__proto__', 'constructor', 'prototype'].includes(fieldName) || Object.hasOwn(fields, fieldName)) fail(400, 'INVALID_MULTIPART', 'Tên trường không hợp lệ hoặc bị lặp.');
      fields[fieldName] = bytes.toString('utf8');
    }
  }
  if (files.length !== 1) fail(400, 'INVALID_MULTIPART', 'Hãy thêm trường file kiểu File và chọn sample-upload.txt.');
  return { fields, files };
}
function routeMethods(path) {
  if (path === '/health') return ['GET'];
  if (path === '/auth/login') return ['POST'];
  if (path === '/products') return ['GET', 'POST'];
  if (/^\/products\/\d+$/.test(path)) return ['GET', 'PATCH', 'DELETE'];
  if (path === '/private/profile') return ['GET'];
  if (path === '/echo' || path === '/upload') return ['POST'];
  return null;
}
const server = http.createServer(async (req, res) => {
  res.setHeader('Access-Control-Allow-Origin', '*');
  res.setHeader('Access-Control-Allow-Headers', 'Content-Type, Authorization, X-Lab-Note');
  res.setHeader('Access-Control-Expose-Headers', 'Location');
  try {
    const url = new URL(req.url, `http://${host === '::1' ? '[::1]' : host}:${port}`);
    const methods = routeMethods(url.pathname);
    if (!methods) fail(404, 'NOT_FOUND', 'Không tìm thấy đường dẫn.');
    res.setHeader('Access-Control-Allow-Methods', [...methods, 'OPTIONS'].join(', '));
    if (req.method === 'OPTIONS') return empty(res, 204);
    allow(req, res, methods);
    if (url.pathname === '/health') return json(res, 200, { status: 'ok', service: 'postman-practice' });
    if (url.pathname === '/auth/login') {
      const body = await readJson(req);
      if (!object(body) || typeof body.email !== 'string' || typeof body.password !== 'string') fail(400, 'INVALID_LOGIN', 'Cần email và password kiểu chuỗi.');
      if (body.email !== EMAIL || body.password !== PASSWORD) fail(401, 'INVALID_CREDENTIALS', 'Thông tin đăng nhập bài học không đúng.');
      const token = randomBytes(32).toString('base64url');
      const expiresIn = 3600;
      for (const [key, session] of sessions) if (session.expiresAt <= Date.now()) sessions.delete(key);
      sessions.set(token, { email: EMAIL, role: 'learner', expiresAt: Date.now() + expiresIn * 1000 });
      return json(res, 200, { access_token: token, token_type: 'Bearer', expires_in: expiresIn });
    }
    if (url.pathname === '/private/profile') {
      const session = authorize(req);
      return json(res, 200, { email: session.email, role: session.role });
    }
    if (url.pathname === '/products') {
      if (req.method === 'GET') {
        const page = positiveInt(url.searchParams.get('page'), 1, 1000000, 'page');
        const limit = positiveInt(url.searchParams.get('limit'), 10, 100, 'limit');
        const q = (url.searchParams.get('q') || '').toLocaleLowerCase('vi');
        const list = [...products.values()].filter(p => p.name.toLocaleLowerCase('vi').includes(q));
        return json(res, 200, { data: list.slice((page - 1) * limit, page * limit), page, limit, total: list.length });
      }
      authorize(req);
      const data = validateProduct(await readJson(req));
      const product = { id: nextId++, ...data };
      products.set(product.id, product);
      return json(res, 201, product, { Location: `/products/${product.id}` });
    }
    const productMatch = /^\/products\/(\d+)$/.exec(url.pathname);
    if (productMatch) {
      if (req.method !== 'GET') authorize(req);
      const id = Number(productMatch[1]);
      const product = products.get(id);
      if (!product) fail(404, 'PRODUCT_NOT_FOUND', 'Không tìm thấy sản phẩm.');
      if (req.method === 'GET') return json(res, 200, product);
      if (req.method === 'DELETE') { products.delete(id); return empty(res, 204); }
      Object.assign(product, validateProduct(await readJson(req), true));
      return json(res, 200, product);
    }
    if (url.pathname === '/echo') {
      const type = mediaType(req);
      let body;
      if (type === 'application/json') body = await readJson(req);
      else if (type === 'application/x-www-form-urlencoded') body = Object.fromEntries(new URLSearchParams((await readBody(req)).toString('utf8')));
      else fail(415, 'UNSUPPORTED_MEDIA_TYPE', 'Echo nhận JSON hoặc x-www-form-urlencoded.');
      return json(res, 200, { method: req.method, query: Object.fromEntries(url.searchParams), headers: safeHeaders(req), body });
    }
    if (url.pathname === '/upload') {
      if (mediaType(req) !== 'multipart/form-data') fail(415, 'UNSUPPORTED_MEDIA_TYPE', 'Hãy chọn Body → form-data, trường file kiểu File.');
      return json(res, 200, multipart(req, await readBody(req)));
    }
  } catch (error) {
    if (res.headersSent) return res.end();
    const known = error instanceof ApiError;
    json(res, known ? error.status : 500, { error: { code: known ? error.code : 'INTERNAL_ERROR', message: known ? error.message : 'Lỗi nội bộ của API bài học.' } });
  }
});
server.requestTimeout = 15000;
server.headersTimeout = 10000;
server.listen(port, host, () => {
  console.log(`API bài học: http://${host === '::1' ? '[::1]' : host}:${port}`);
  console.log('Chỉ phục vụ trên máy này. Ctrl+C để dừng; dữ liệu được đặt lại khi khởi động lại.');
});
server.on('error', error => {
  console.error(error.code === 'EADDRINUSE' ? `Cổng ${port} đang được dùng. Dừng server cũ hoặc chọn POSTMAN_LAB_PORT khác.` : error.message);
  process.exitCode = 1;
});
